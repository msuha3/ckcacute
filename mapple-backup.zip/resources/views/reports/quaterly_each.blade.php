@extends("layouts.app")
@section("content")
<div class="card">
    <div class="card-header">
        <h2 class="text-center">Hospital Acute Dialysis</h2>
        <h4 class="text-center">Quarterly Quality Report</h4>
        <h4 class="text-center">Report Date Range: {{ $report_data['date_range'] }}</h4>
       
    </div>

    <div class="card-block table-border-style">

        @if (session('msg'))
            <div class="alert alert-success" style="width:80%; margin:auto">
                {{ session('msg') }}
            </div>
        @endif

        <div class="table-responsive">
            <form method="post" action="{{ url('update_quaterly_report') }}">
                 @csrf
            <table class="table table-bordered data-table" style="width:80%; table-layout: fixed;" align="center">
                <tbody>    
                    <tr><td colspan="2" class="text-center" style="background:#009E47; color:#FFF">Summary</td></tr>
                    <tr><td>Total treatments performed</td><td>{{ $report_data['total'] }}</td></tr>
                    <tr><td>Total cancelled treatments</td><td>{{ $report_data['cancelled'] }}</td></tr>
                    <tr><td>Hemodialysis</td><td>{{ $report_data['hemodialysis'] }}</td></tr>
                    <tr><td>Peritoneal Dialysis</td><td>{{ $report_data['peritoneal'] }}</td></tr>
                    <tr><td>Treatments performed in the DAY</td><td>{{ $report_data['day_treatments'] }}</td></tr>
                    <tr><td>Treatments performed in the NIGHT</td><td>{{ $report_data['night_treatments'] }}</td></tr>
                    <tr><td>Treatments performed in the WEEKEND</td><td>{{ $report_data['weekend_treatments'] }}</td></tr>
                    <tr><td>Holiday</td><td>{{ $report_data['holiday_treatments'] }}</td></tr>

                    <tr><td colspan="2" class="text-center" style="background:#009E47; color:#FFF">Treatment Goals</td></tr>

                    <tr><td>Achieved Prescribed Time Goal</td><td>{{ ($report_data['prescribed_time_goal']>0)?number_format($report_data['prescribed_time_goal']/$report_data['total']*100,0):0 }}%</td></tr>
                    <tr><td>Achieved Prescribed Ultra Filtration Goal</td><td>{{ ($report_data['prescribed_filtration_goal'] > 0)?number_format($report_data['prescribed_filtration_goal']/$report_data['total']*100,0):0 }}%</td></tr>

                    <tr><td colspan="2" class="text-center" style="background:#009E47; color:#FFF">Admission Diagnosis Break Down</td></tr>

                    <tr><td>Cardiac Related</td><td>{{ $report_data['cardiac_related'] }}</td></tr>
                    <tr><td>Fever/Sepsis/Infection Related</td><td>{{ $report_data['fever_related'] }}</td></tr>
                    <tr><td>Surgery/Other Scheduled Procedure Related</td><td>{{ $report_data['surgery_related'] }}</td></tr>
                    <tr><td>GI Related</td><td>{{ $report_data['gi_related'] }}</td></tr>
                    <tr><td>Electrolyte Imbalance Related</td><td>{{ $report_data['electrolyte_related'] }}</td></tr>
                    <tr><td>SOB/Fluid Overload Related</td><td>{{ $report_data['sob_related'] }}</td></tr>
                    <tr><td>Physical Injury Related</td><td>{{ $report_data['injury_related'] }}</td></tr>
                    <tr><td>Neural Related</td><td>{{ $report_data['neural_related'] }}</td></tr>
                    <tr><td>Blood Transfusion Related</td><td>{{ $report_data['transfusion_related'] }}</td></tr>
                    <tr><td>Respiratory Related</td><td>{{ $report_data['respiratory_related'] }}</td></tr>
                    <tr><td>Other</td><td>{{ $report_data['other'] }}</td></tr>

                    <tr><td colspan="2" class="text-center" style="background:#009E47; color:#FFF">Adverse Events Summary</td></tr>
                    <tr><td>Treatments WITHOUT an Adverse Event</td><td><input class="form-control"  type="text" name="treatments_wo_dverse" value="{{ $report_data['treatments_wo_dverse'] }}"></td></tr>
                    <tr><td>Treatments WITH an Adverse Event</td><td><input class="form-control"  type="text" name="treatments_w_dverse" value="{{ $report_data['treatments_w_dverse'] }}"></td></tr>

                    <tr><td colspan="2" class="text-center" style="background:#009E47; color:#FFF">Adverse Events Break Down</td></tr>

                    <tr><td>Significant blood pressure change</td><td><input class="form-control"  type="text" name="bloodpressure_change" value="{{ $report_data['bloodpressure_change'] }}"></td></tr>
                    <tr><td>Significant temperature change</td><td><input class="form-control"  type="text" name="temperature_change" value="{{ $report_data['temperature_change'] }}"></td></tr>
                    <tr><td>Significant blood loss</td><td><input class="form-control"  type="text" name="blood_loss" value="{{ $report_data['blood_loss'] }}"></td></tr>
                    <tr><td>Clotted blood lines</td><td><input class="form-control"  type="text" name="clotted_blood_lines" value="{{ $report_data['clotted_blood_lines'] }}"></td></tr>
                    <tr><td>Clotted access</td><td><input class="form-control"  type="text" name="clotted_access" value="{{ $report_data['clotted_access'] }}"></td></tr>
                    <tr><td>Power outage</td><td><input class="form-control"  type="text" name="power_outage" value="{{ $report_data['power_outage'] }}"></td></tr>
                    <tr><td>Machine system failure</td><td><input class="form-control"  type="text" name="machine_system_failure" value="{{ $report_data['machine_system_failure'] }}"></td></tr>
                    <tr><td>Machine system fluid leak</td><td><input class="form-control"  type="text" name="machine_system_fluid_leak" value="{{ $report_data['machine_system_fluid_leak'] }}"></td></tr>
                    <tr><td>Allergic reaction (blood, meds, etc.)</td><td><input class="form-control"  type="text" name="allergic_reaction" value="{{ $report_data['allergic_reaction'] }}"></td></tr>
                    <tr><td>Required change in level of care (move to ICU, etc.)</td><td><input class="form-control"  type="text" name="change_care_level" value="{{ $report_data['change_care_level'] }}"></td></tr>
                    <tr><td>Unable to accomplish ordered outcome</td><td><input class="form-control"  type="text" name="Unable_ordered_outcome" value="{{ $report_data['Unable_ordered_outcome'] }}"></td></tr>
                    <tr><td>Other*</td><td><input class="form-control"  type="text" name="adverse_events_other" value="{{ $report_data['adverse_events_other'] }}"></td></tr>

                    <tr><td colspan="2" class="text-center" style="background:#009E47; color:#FFF">Record Audit</td></tr>

                    <tr><td>Number of flowsheets audited</td><td><input class="form-control" type="text" name="flowsheets_audited" value="{{ $report_data['flowsheets_audited'] }}"></td></tr>

                    <tr><td colspan="2" class="text-center" style="background:#009E47; color:#FFF">Dialysis PCT Documentation Summary</td></tr>

                    <tr><td colspan="2">
                        <div class="table-responsive">
                        <table class="table table-bordered data-table pct_summary" style="width: 60%;">
                            <tr><th>PCT Name</th><th>CPR Expiration</th><th>Dialysis Certification</th><th>OPH Orientation</th><th>Annual Competency</th><th>Age-specific Competence</th><th>Performance Evaluations</th><th>Covid Vaccination
1st Dose</th><th>Covid Vaccination
2nd Dose</th><th>Covid Vaccination Booster</th></tr>

<tr>
    <td><input class="form-control" type="text" name="pct_name[]" value="{{ $pct_summary[0]['pct_name'] }}"></td>
    <td><input class="form-control" type="text" name="cpr_expiration[]" value="{{ $pct_summary[0]['cpr_expiration'] }}"></td>
    <td><input class="form-control" type="text" name="dialysis_certification[]" value="{{ $pct_summary[0]['dialysis_certification'] }}"></td>
    <td><input class="form-control" type="text" name="oph_orientation[]" value="{{ $pct_summary[0]['oph_orientation'] }}"></td>
    <td><input class="form-control" type="text" name="annual_competency[]" value="{{ $pct_summary[0]['annual_competency'] }}"></td>
    <td><input class="form-control" type="text" name="age_specific_competence[]" value="{{ $pct_summary[0]['age_specific_competence'] }}"></td>
    <td><input class="form-control" type="text" name="performance_evaluations[]" value="{{ $pct_summary[0]['performance_evaluations'] }}"></td>
    <td><input class="form-control" type="text" name="covid_vaccination_1st_dose[]" value="{{ $pct_summary[0]['covid_vaccination_1st_dose'] }}"></td>
    <td><input class="form-control" type="text" name="covid_vaccination_2nd_dose[]" value="{{ $pct_summary[0]['covid_vaccination_2nd_dose'] }}"></td>
    <td><input class="form-control" type="text" name="covid_vaccination_booster[]" value="{{ $pct_summary[0]['covid_vaccination_booster'] }}"></td></tr>

<tr><td><input class="form-control" type="text" name="pct_name[]" value="{{ $pct_summary[1]['pct_name'] }}"></td><td><input class="form-control" type="text" name="cpr_expiration[]" value="{{ $pct_summary[1]['cpr_expiration'] }}"></td><td><input class="form-control" type="text" name="dialysis_certification[]" value="{{ $pct_summary[1]['dialysis_certification'] }}"></td><td><input class="form-control" type="text" name="oph_orientation[]" value="{{ $pct_summary[1]['oph_orientation'] }}"></td><td><input class="form-control" type="text" name="annual_competency[]" value="{{ $pct_summary[1]['annual_competency'] }}"></td><td><input class="form-control" type="text" name="age_specific_competence[]" value="{{ $pct_summary[1]['age_specific_competence'] }}"></td><td><input class="form-control" type="text" name="performance_evaluations[]" value="{{ $pct_summary[1]['performance_evaluations'] }}"></td><td><input class="form-control" type="text" name="covid_vaccination_1st_dose[]" value="{{ $pct_summary[1]['covid_vaccination_1st_dose'] }}"></td><td><input class="form-control" type="text" name="covid_vaccination_2nd_dose[]" value="{{ $pct_summary[1]['covid_vaccination_2nd_dose'] }}"></td><td><input class="form-control" type="text" name="covid_vaccination_booster[]" value="{{ $pct_summary[1]['covid_vaccination_booster'] }}"></td></tr>

<tr><td><input class="form-control" type="text" name="pct_name[]" value="{{ $pct_summary[2]['pct_name'] }}"></td><td><input class="form-control" type="text" name="cpr_expiration[]" value="{{ $pct_summary[2]['cpr_expiration'] }}"></td><td><input class="form-control" type="text" name="dialysis_certification[]" value="{{ $pct_summary[2]['dialysis_certification'] }}"></td><td><input class="form-control" type="text" name="oph_orientation[]" value="{{ $pct_summary[2]['oph_orientation'] }}"></td><td><input class="form-control" type="text" name="annual_competency[]" value="{{ $pct_summary[2]['annual_competency'] }}"></td><td><input class="form-control" type="text" name="age_specific_competence[]" value="{{ $pct_summary[2]['age_specific_competence'] }}"></td><td><input class="form-control" type="text" name="performance_evaluations[]" value="{{ $pct_summary[2]['performance_evaluations'] }}"></td><td><input class="form-control" type="text" name="covid_vaccination_1st_dose[]" value="{{ $pct_summary[2]['covid_vaccination_1st_dose'] }}"></td><td><input class="form-control" type="text" name="covid_vaccination_2nd_dose[]" value="{{ $pct_summary[2]['covid_vaccination_2nd_dose'] }}"></td><td><input class="form-control" type="text" name="covid_vaccination_booster[]" value="{{ $pct_summary[2]['covid_vaccination_booster'] }}"></td></tr>

<tr><td><input class="form-control" type="text" name="pct_name[]" value="{{ $pct_summary[3]['pct_name'] }}"></td><td><input class="form-control" type="text" name="cpr_expiration[]" value="{{ $pct_summary[3]['cpr_expiration'] }}"></td><td><input class="form-control" type="text" name="dialysis_certification[]" value="{{ $pct_summary[3]['dialysis_certification'] }}"></td><td><input class="form-control" type="text" name="oph_orientation[]" value="{{ $pct_summary[3]['oph_orientation'] }}"></td><td><input class="form-control" type="text" name="annual_competency[]" value="{{ $pct_summary[3]['annual_competency'] }}"></td><td><input class="form-control" type="text" name="age_specific_competence[]" value="{{ $pct_summary[3]['age_specific_competence'] }}"></td><td><input class="form-control" type="text" name="performance_evaluations[]" value="{{ $pct_summary[3]['performance_evaluations'] }}"></td><td><input class="form-control" type="text" name="covid_vaccination_1st_dose[]" value="{{ $pct_summary[3]['covid_vaccination_1st_dose'] }}"></td><td><input class="form-control" type="text" name="covid_vaccination_2nd_dose[]" value="{{ $pct_summary[3]['covid_vaccination_2nd_dose'] }}"></td><td><input class="form-control" type="text" name="covid_vaccination_booster[]" value="{{ $pct_summary[3]['covid_vaccination_booster'] }}"></td></tr>


<tr><td><input class="form-control" type="text" name="pct_name[]" value="{{ $pct_summary[4]['pct_name'] }}"></td><td><input class="form-control" type="text" name="cpr_expiration[]" value="{{ $pct_summary[4]['cpr_expiration'] }}"></td><td><input class="form-control" type="text" name="dialysis_certification[]" value="{{ $pct_summary[4]['dialysis_certification'] }}"></td><td><input class="form-control" type="text" name="oph_orientation[]" value="{{ $pct_summary[4]['oph_orientation'] }}"></td><td><input class="form-control" type="text" name="annual_competency[]" value="{{ $pct_summary[4]['annual_competency'] }}"></td><td><input class="form-control" type="text" name="age_specific_competence[]" value="{{ $pct_summary[4]['age_specific_competence'] }}"></td><td><input class="form-control" type="text" name="performance_evaluations[]" value="{{ $pct_summary[4]['performance_evaluations'] }}"></td><td><input class="form-control" type="text" name="covid_vaccination_1st_dose[]" value="{{ $pct_summary[4]['covid_vaccination_1st_dose'] }}"></td><td><input class="form-control" type="text" name="covid_vaccination_2nd_dose[]" value="{{ $pct_summary[4]['covid_vaccination_2nd_dose'] }}"></td><td><input class="form-control" type="text" name="covid_vaccination_booster[]" value="{{ $pct_summary[4]['covid_vaccination_booster'] }}"></td></tr>

                        </table>
                    </div>
                    </td>
                        
                    </tr>

                    <tr><td colspan="2" class="text-center">
                        <input type="hidden" name="id" value="{{ $report_data['id'] }}">
                        <input type="submit" class="btn btn-success mt-3" value="Update Report" name="update"></td></tr>
                    
                </tbody>
            </table>
            
        </form>
        </div>
    </div>
</div>

<style type="text/css">
    input[type="text"]{
        width: 40%;
    }

    .pct_summary input[type="text"] {
        width: 70%;
    }

    .pct_summary th{
        font-weight: bold;
    }
</style>
@endsection