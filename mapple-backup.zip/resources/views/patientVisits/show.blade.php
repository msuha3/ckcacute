@extends("layouts.app")
@section("content")
<div class="card">
    <div class="card-header">
        <h5>Patient Record Table</h5>
        <span>use class <code>table</code> inside table element</span>
        <div class="card-header-right">
            <ul class="list-unstyled card-option">
                <li>
                    <a class="btn btn-primary" href="{{url("patientVisits/create")}}">Add visit</a>
                </li>
                
            </ul>
        </div>
    </div>
    <div class="card-block table-border-style">
        <div class="table-responsive">
            <table class="table table-hover data-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th class="table-info">Inv ID</th>
                        <th class="table-secondary">Tx ID</th>
                        <th>Last Name</th>
                        <th>First Name</th>
                        <th>Date</th>
                        <th>Room</th>
                        <th>Account #</th>
                        <th>Dx Code (1-13)</th>
                        <th>Goal Meet Time</th>
                        <th>Goal Meet UF</th>
                        <th>Modality</th>
                        <th>Time Start</th>
                        <th>Time End</th>
                        <th>Amount</th>
                        <th>Comment</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($patientVisits as $key=>$item)
                        <?php 
                        $patientDetails = 
                        \App\Models\Patients::find($item->patient_id);
                        ?>
                    <tr>
                        <td>{{++$key}}</td>
                        <td class="table-info">{{$item->invoice_number}}</td>
                        <td class="table-secondary"> {{$item->tx_number}}</td>
                        <td>{{$patientDetails->last_name}}</td>
                        <td>{{$patientDetails->first_name}}</td>
                        <td>{{$item->date}}</td>
                        <td>{{$item->room}}</td>
                        <td>{{$patientDetails->id}}</td>
                        <td>{{$item->dx_code}}</td>
                        <td>
                         {!! ($item->gmt == "Y")
                         ? "<span class='text-success'>Yes</span>" 
                         : "<span class='text-danger'>No</span>"  !!}   
                        </td>
                        <td>
                            {!! ($item->gmu == "Y")
                         ? "<span class='text-success'>Yes</span>" 
                         : "<span class='text-danger'>No</span>"  !!}   
                        </td>
                        <td><span class="text-primary">{{$item->modality}}</span></td>
                        <td>{{$item->time_start}}</td>
                        <td>{{$item->time_end}}</td>
                        <td><b>$ {{$item->amount}} </b></td>
                        <td>{{$item->signature}}</td>
                        <td>
                            <div class="d-inline-flex">
                                <a 
                                href="{{url("patientVisits/".$item->id."/edit")}}"
                                class="text-success flex  mr-3">
                                    <i class="fa fa-edit"></i>
                                </a>
                                <form
                                id="delete-form{{$item->id}}" 
                                action="{{url("patientVisits/".$item->id)}}" method="post" class="d-none delete-form">
                                @csrf
                                @method("DELETE")
                                </form>
                                <a
                                href="javascript:confirmDeleteForm('{{$item->id}}')"
                                {{-- href="javascript:document.getElementById('delete-form{{$item->id}}').submit()"  --}}
                                    
                                    class="text-danger flex">
                                    <i class="fa fa-trash"></i>
                                </a>
                            </div>
                            
                        </td>
                    </tr>
                    @endforeach
                   
                   
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection