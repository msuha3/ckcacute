<!DOCTYPE html>
<html lang="en">
<head>
  <title>{{"Patient Invoice ".date("Y/m/d") }}</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

    <div class="container">
        <a href="javascript:window.print()">print</a>
        <div class="card">
      <div class="card-header">
      Invoice at
      <strong>{{date("Y/m/d")}}</strong> 
        <span class="float-right"> <strong>Status:</strong> Pending</span>
      
      </div>
      <div class="card-body">
      <div class="row mb-4">
      <div class="col-sm-6">
      <h6 class="mb-3">From:</h6>
      <div>
      <strong>Webz Poland</strong>
      </div>
      <div>Madalinskiego 8</div>
      <div>71-101 Szczecin, Poland</div>
      <div>Email: info@webz.com.pl</div>
      <div>Phone: +48 444 666 3333</div>
      </div>
      
      <div class="col-sm-6">
      <h6 class="mb-3">To:</h6>
      <div>
      <strong>Bob Mart</strong>
      </div>
      <div>Attn: Daniel Marek</div>
      <div>43-190 Mikolow, Poland</div>
      <div>Email: marek@daniel.com</div>
      <div>Phone: +48 123 456 789</div>
      </div>
      
      
      
      </div>
      
      <div class="table-responsive-sm">
      <table class="table table-striped">
      <thead>
      <tr>
      <th class="center">Treatment #</th>
      <th>Date</th>
      <th>Last Name</th>
      
      <th class="right">First Name</th>
        <th class="center">Account #</th>
      <th class="right">Modality</th>
      <th class="right">Std Rate</th>
      <th class="right">Oth Rate</th>
      <th class="right">Charge</th>
    </tr>
      </thead>
      <tbody>
        <?php $total = 0;?>
        @foreach($patientVisits as $item)
        <?php 
        $patientDetails = 
        \App\Models\Patients::find($item->patient_id);
        ?>
      <tr>
      <td class="center">{{$item->id}}</td>
      <td class="left strong">{{$item->date}}</td>
      <td class="left">{{$patientDetails->last_name}}</td>
      <td class="left">{{$patientDetails->first_name}}</td>
      <td class="left">{{$item->patient_id}}</td>
      
      <td class="left">{{$item->modality}}</td>
      <td class="right">X</td>
      <td class="right"></td>
      <td class="right">$ {{$item->amount}}</td>
      </tr>
      <?php $total += $item->amount ;?>
      @endforeach
     
     
      
      </tbody>
      </table>
      </div>
      <div class="row">
      <div class="col-lg-4 col-sm-5">
      
      </div>
      
      <div class="col-lg-4 col-sm-5 ml-auto">
      <table class="table table-clear">
      <tbody>
     
      <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td class="left">
      <strong>Total</strong>
      </td>
      <td class="right">
      <strong>$ {{$total}}</strong>
      </td>
      </tr>
      </tbody>
      </table>
      
      </div>
      
      </div>
      
      </div>
      </div>
      </div>
</body>
</html>
