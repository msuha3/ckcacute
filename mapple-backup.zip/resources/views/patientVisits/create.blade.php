@extends('layouts.app')
@section('content')
    @if ($errors->any())
        {!! implode('', $errors->all('<div class="text-danger">:message</div>')) !!}
    @endif
    <form class="form-material" method="post" action="{{ url('patientVisits') }}">
        @csrf
        <div class="row">
            <div class="col-md-6">
                <div class="card rounded-18 shadow-lg">
                    <div class="card-header">
                        <h5>Patient Detail form</h5>

                    </div>
                    <div class="card-block">
                        <div class="row w-100">
                            <div class="col-lg-12">
                                <div class="form-group form-default">
                                    <select  name="patient_id" class="form-control" required>
                                        <option value="-1">Select Patient</option>
                                        @foreach(\App\Models\Patients::all() as $patient)
                                        <option value="{{$patient->id}}">
                                        {{$patient->id}} | {{$patient->last_name}}, {{$patient->first_name}}
                                        </option>
                                        @endforeach
                                    </select>
                                    @error('patient_id')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                           
                        </div>

                        <div class="row w-100">
                            <div class="col-lg-6">
                                <div class="form-group form-default">
                                    <input type="date" name="date" class="form-control" required
                                        value="{{ old('date') ?? date('Y-m-d') }}">
                                    @error('date')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="float-label"></label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group form-default">
                                    <select type="number" name="room" class="form-control" required="">
                                        @for ($i = 1; $i <= 10; $i++)
                                            <option value="{{ $i }}"
                                                @if (old('room') !== null && old('room') == $i) selected @endif>{{ $i }}
                                            </option>
                                        @endfor
                                    </select>
                                    @error('last_name')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="float-label">Room #</label>
                                </div>
                            </div>
                        </div>

                        <div class="row w-100">
                            
                            <div class="col-lg-6">
                                <div class="form-group form-default">
                                    <select class="form-control" name="dx_code">
                                        <option value="1">1. Cardiac Related</option>
                                        <option value="2">2.   Fever/Sepsis/Infection Related</option>
                                        <option value="3">3.    Surgery/Other Scheduled Procedure Related</option>
                                        <option value="4">4.    GI Related</option>
                                        <option value="5">5.    Electrolyte Imbalance Related</option>
                                        <option value="6">6.    SOB/Fluid Overload Related</option>
                                        <option value="7">7.    Physical Injury Related</option>
                                        <option value="8">8.    Neural Related</option>
                                        <option value="9">9.    Blood Transfusion Related</option>
                                        <option value="10">10.   Respiratory Related</option>
                                        <option value="11">11.   Other</option>
                                    </select>
                                    
                                    @error('dx_code')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="float-label">Dx Code (1-13)</label>
                                </div>
                            </div>
                        </div>


                        <div class="row w-100">
                            <div class="col-lg-6">
                                <div class="form-group form-default">
                                    <small style="">Goal Meet Time</small>

                                    <select name="gmt" class="form-control" required>
                                        <option value="Y"
                                            @if (old('gmt') !== null) && old('gmt') == "Y") selected @endif>yes
                                        </option>
                                        <option value="N"
                                            @if (old('gmt') !== null) && old('gmt') == "N") selected @endif>no
                                        </option>
                                    </select>

                                    @error('gmt')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group form-default">
                                    <small style="">Goal Meet UF</small>

                                    <select name="gmu" class="form-control" required>
                                        <option value="Y"
                                            @if (old('gmu') !== null) && old('gmu') == "Y") selected @endif>yes
                                        </option>
                                        <option value="N"
                                            @if (old('gmu') !== null) && old('gmu') == "N") selected @endif>no
                                        </option>
                                    </select>

                                    @error('gmu')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card rounded-18 shadow-lg">
                    <div class="card-header">
                        <h5>More information</h5>
                        <!--<span>Add class of <code>.form-control</code> with <code>&lt;input&gt;</code> tag</span>-->
                    </div>
                    <div class="card-block">
                        <div class="row w-100">
                            <div class="col-lg-6">
                                <div class="form-group form-default form-static-label">
                                    <select class="form-control" name="modality">
                                        <option value="Hemo">Hemodialysis</option>
                                        <option value="Peritoneal">Peritoneal Dialysis</option>
                                    </select>
                                    
                                    @error('modality')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="float-label">Modality</label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group form-default form-static-label">
                                    <input type="time" name="time_start" class="form-control" placeholder="Time" value="{{old("start_time")}}">
                                    @error('time_start')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror <label class="float-label">Time Tx Started</label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group form-default form-static-label">
                                    <input type="time" name="time_end" class="form-control" placeholder="Time" value="{{old("time_end")}}">
                                    @error('time_end')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror <label class="float-label">Time Tx End</label>
                                </div>
                            </div>
                        </div>

                        <div class="row w-100">
                            <div class="col-lg-6">
                                <div class="form-group form-default form-static-label">
                                    <input type="number" step="0.1"  name="night_rate" class="form-control" placeholder="e.g 400" value="{{old("night_rate")}}">
                                    @error('night_rate')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror <label class="float-label">Night Rate</label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group form-default form-static-label">
                                    <input type="number" step="0.1"  name="holiday_rate" class="form-control">
                                    @error('holiday_rate')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror <label class="float-label">Holiday Rate</label>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group form-default form-static-label">
                                        <input type="number" step="0.1"  name="weekend_rate" class="form-control" placeholder="e.g 400" value="{{old("weekend_rate")}}">
                                        @error('weekend_rate')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror <label class="float-label">Weekend Rate</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group form-default form-static-label">
                                        <input type="number" step="0.1" name="amount" class="form-control" placeholder="e.g 400" value="{{old("amount")}}">
                                        @error('amount')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror <label class="float-label">Weekend Rate</label>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group form-default form-static-label">
                                    <input type="text" name="invoice_number" class="form-control"
                                        value="" placeholder="{{ time() . '-' . Auth::id() }}">
                                    @error('invoice_number')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror <label class="float-label">Invoice Number</label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group form-default form-static-label">
                                    <input type="text" name="tx_number" class="form-control"
                                    value="" placeholder="{{old('tx_number') ?? rand(100000,999999)}}" 
                                    >
                                    @error('tx_number')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror <label class="float-label">TX number</label>
                                </div>
                            </div>
                        </div>


                        <div class="form-group form-default form-static-label">
                            <textarea class="form-control" name="signature"></textarea>
                            @error('signature')
                                <span class="text-danger">{{ $message }}</span>
                            @enderror <label class="float-label">comment</label>
                        </div>

                       
                        <div class="row "style="margin-top: 50px">
                            @if(auth()->user()->role == 'admin')
                            <div class="col-lg-6">
                            <div class="form-group form-default form-static-label">
                                <select class="form-control" name="user_id">
                                    <option value=""></option>
                                    @foreach(\App\Models\Employee::where("role", "tech")->get() as $itemTech)
                                    <option value="{{$itemTech->id}}">{{$itemTech->first_name ." " .$itemTech->last_name}}</option>
                                    @endforeach
                                </select>
                                @error('signature')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror <label class="float-label">Tech Name</label>
                            </div>
                        </div>
                        @else
                            <input type="hidden" name="user_id" value="{{ auth()->user()->id }}">
                        @endif
    
                        <div class="col-lg-6">
                            <div class=" form-group form-default form-static-label">
                                <select class="form-control" name="hospital_id">
                                    <option value=""></option>
                                    @foreach(\App\Models\Hospitals::get() as $itemH)
                                    <option value="{{$itemH->id}}">{{$itemH->name}}</option>
                                    @endforeach
                                </select>
                                @error('signature')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror <label class="float-label">Hospital Name</label>
                            </div>
                        </div>
                            <div class="d-none col-lg-6 form-group form-default form-static-label">
                                <select class="form-control" name="status">
                                    <option 
                                    
                                    value="pending">pending</option>
                                    
                                </select>
                               
                            </div>
                        </div>
                        
                    </div>

                   
                    <div class="p-4 w-100">
                        <button class="btn btn-primary ">Save</button>
                    </div>
                </div>

            </div>
        </div>


    </form>

    <br><br><br><br>
    <br><br><br><br>
    <br><br><br><br>
@endsection
