@extends('layouts.app')

@section('content')
    <div class="row">
        <!-- task, page, download counter  start -->
        <div class="col-xl-4 col-md-6">
            <div class="card">
                <div class="card-header bg-c-purple">
                    <div class="row align-items-center">
                        <div class="col-9">
                            <p class="text-white m-b-0">Total Patients</p>
                        </div>
                        <div class="col-3 text-right">
                            <i class="fa fa-users"></i>
                        </div>
                    </div>
                </div>
                <div class="card-block">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h4 class="text-c-purple">{{ \App\Models\Patients::count() }}</h4>
                            <h6 class="text-muted m-b-0"></h6>
                        </div>
                        <div class="col-4 text-right">
                            <i class="fa fa-bar-chart f-28"></i>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="col-xl-4 col-md-6">
            <div class="card">
                <div class="card-header bg-c-purple">
                    <div class="row align-items-center">
                        <div class="col-9">
                            <p class="text-white m-b-0">Today Visits</p>
                        </div>
                        <div class="col-3 text-right">
                            <i class="fa fa-line-chart text-white f-16"></i>
                        </div>
                    </div>
                </div>
                <div class="card-block">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h4 class="text-c-green">{{\App\Models\patientVisits::where("date",date("Y-m-d"))->count()}}</h4>
                            <h6 class="text-muted m-b-0"></h6>
                        </div>
                        <div class="col-4 text-right">
                            <i class="fa fa-file-text-o f-28"></i>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="col-xl-4 col-md-6">
            <div class="card">
                <div class="card-header bg-c-purple">
                    <div class="row align-items-center">
                        <div class="col-9">
                            <p class="text-white m-b-0">Staff</p>
                        </div>
                        <div class="col-3 text-right">
                            <i class="fa fa-line-chart text-white f-16"></i>
                        </div>
                    </div>
                </div>
                <div class="card-block">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h4 class="text-c-red">
                              {{\App\Models\Employee::where("role","tech")->count()}}
                            </h4>
                            <h6 class="text-muted m-b-0">
                                
                            </h6>
                        </div>
                        <div class="col-4 text-right">
                            <i class="fa fa-calendar-check-o f-28"></i>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        
        <!-- task, page, download counter  end -->

        <!--  project and team member start -->
        <div class="col-xl-8 col-md-12">
            <div class="card table-card">
                <div class="card-header">
                    <h5>Recent visits</h5>
                    <div class="card-header-right">
                        <i class="fas fa-project-diagram big-icon"></i>
                    </div>
                </div>
                <div class="card-block" style="max-height: 600px; overflow-y:scroll">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>Attended By</th>

                                    <th>Patient Name
                                    </th>
                                    <th>Account #</th>
                                    <th>Room</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($patientLatestVisits as $key => $item)
                                    <?php
                                    $patientDetails = \App\Models\Patients::find($item->patient_id);
                                    ?>
                                    <tr>
                                        <td>
                                    <div class="d-inline-flex">
                                        <a href="{{ url('patientVisits/' . $item->id . '/edit') }}"
                                            class="text-success flex  mr-3">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                        <form id="delete-form{{ $item->id }}"
                                            action="{{ url('patientVisits/' . $item->id) }}" method="post"
                                            class="d-none delete-form">
                                            @csrf
                                            @method('DELETE')
                                        </form>
                                        <a href="javascript:confirmDeleteForm('{{ $item->id }}')" {{-- href="javascript:document.getElementById('delete-form{{$item->id}}').submit()" --}}
                                            class="text-danger flex">
                                            <i class="fa fa-trash"></i>
                                        </a>
                                    </div>

                                </td>
                                        <td>
                                          @php
                                          $tech =  \App\Models\Employee::find($item->user_id);
                                           @endphp
                                       @if($tech)
                                       {{$tech->first_name}}
                                       {{$tech->last_name}}
                                       @endif
                                        </td>
                                        <td>
                                            {{ $patientDetails->first_name }}
                                            {{ $patientDetails->last_name }}

                                        </td>
                                        <td>{{ $patientDetails->id }}</td>
                                        <td>{{ $item->room }}</td>
                                        <td>{{ $item->date }}</td>
                                        <td>
                                          {!!$item->status == "completed" 
                                          ? "<label class='label label-success'>".$item->status."</label>" : ""!!}
                                           {!!$item->status == "pending" 
                                           ? "<label class='label label-danger'>".$item->status."</label>": ""!!}
                                            {!!$item->status == "in progress" 
                                            ? "<label class='label label-primary'>".$item->status."</label>" : ""!!}
                                            {!!$item->status == "cancelled" 
                                            ? "<label class='label' style='background:black;'>".$item->status."</label>" : ""!!}
                                        </td>
                                        
                                    </tr>
                                @endforeach


                            </tbody>
                        </table>
                        <div class="text-right m-r-20">
                            <a href="{{ url('patientVisits') }}" class="b-b-primary text-primary">View all Visits</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5>Staff Members</h5>
                    <div class="card-header-right">
                      Pending Visits
                    </div>
                </div>
                <div class="card-block" style="max-height: 600px; overflow-y:scroll">
                    @foreach (\App\Models\Employee::where('role', 'tech')->get() as $itemTech)
                        <div class="align-middle m-b-10">

                            <div class="d-inline-block">
                                <a
                                    href="{{ url('patientVisits?hospital_id=&user_id=' . $itemTech->id . '&month=') }}">{{ $itemTech->first_name . ' ' . $itemTech->last_name }}
                                    </a>
                                <p class="text-muted m-b-0">{{ $itemTech->role }}</p>
                                
                            </div>
                            <p class="float-right text-bold text-danger">
                              
                              {{
                              \App\Models\patientVisits::where("user_id", $itemTech->id)
                              ->where("status", "pending")->count()                            
                            }}
                            </p>
                        </div>
                        <hr>
                    @endforeach

                    <div class="text-center">
                        <a href="{{ url('employees') }}" class="b-b-primary text-primary">View all Staff</a>
                    </div>
                </div>
            </div>
        </div>
        <!--  project and team member end -->
    </div>
@endsection
