@extends("layouts.app")
@section("content")
<div class="card">
    <div class="card-header">
        <h5>Patient Record Table</h5>
        <span>use class <code>table</code> inside table element</span>
        <div class="card-header-right">
            <ul class="list-unstyled card-option">
                <li>
                    <a class="btn btn-primary" href="{{url("patients/create")}}">Add New Patient</a>
                </li>
                
            </ul>
        </div>
    </div>
    <div class="card-block table-border-style">
        <div class="table-responsive">
            <table class="table table-hover data-table">
                <thead>
                    <tr>
                        <th>Account #</th>
                      
                        <th>Last Name</th>
                        <th>First Name</th>
                        <th>Contact</th>
                        <th>Address</th>
                        <th>Actions</th>
                       
                </thead>
                <tbody>
                    @foreach ($patients as $key=>$item)
                        
                    
                    <tr>
                        <td>{{++$key}}</td>
                        
                        <td>{{$item->first_name}}</td>
                        <td>{{$item->last_name}}</td>
                        <td>{{$item->contact}}</td>
                        <td>{{$item->address}}</td>
                        <td>
                            <div class="d-inline-flex">
                                <a  title="invoice"
                                href="{{url("patientVisits/".$item->id."/invoice")}}"
                                class="text-dark flex  mr-3">
                                    <small>Invoice</small>
                                    
                                </a>
                                
                                <a 
                                href="{{url("patientVisits/".$item->id)}}"
                                class="text-primary flex  mr-3">
                                <small>Visits</small>
                                </a>
                                <a 
                                href="{{url("patients/DialysisDocumentation/".$item->id)}}"
                                class="text-primary flex  mr-3">
                                    <small>Dialysis</small>
                                </a>
                                <a 
                                href="{{url("patients/".$item->id."/edit")}}"
                                class="text-success flex  mr-3">
                                    <i class="fa fa-edit"></i>
                                </a>
                                <form
                                id="delete-form{{$item->id}}" 
                                action="{{url("patients/".$item->id)}}" method="post" class="d-none delete-form">
                                @csrf
                                @method("DELETE")
                                </form>
                                <a
                                href="javascript:confirmDeleteForm('{{$item->id}}')"
                                {{-- href="javascript:document.getElementById('delete-form{{$item->id}}').submit()"  --}}
                                    
                                    class="text-danger flex">
                                    <i class="fa fa-trash"></i>
                                </a>
                            </div>
                            
                        </td>
                    </tr>
                    @endforeach
                   
                   
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection