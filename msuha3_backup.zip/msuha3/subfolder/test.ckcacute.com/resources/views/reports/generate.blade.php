@extends("layouts.app")
@section("content")
<div class="card">
    <div class="card-header">
        <h2 class="text-center">Hospital Acute Dialysis</h2>
        <h4 class="text-center">Quarterly Quality Report</h4>
        
            <form method="post" action="{{ url('generate_report') }}">
                 @csrf
            <div class="row">
                <div class="col-md-3 text-right mt-2">Report Date Range: </div>
                <div class="col-md-3"><input type="date" name="start_date" value="{{request()->input('start_date')}}" class="form-control"></div>
                <div class="col-md-3"><input type="date" name="end_date" value="{{request()->input('end_date')}}" class="form-control"></div>
                <div class="col-md-3 text-left"><input type="submit" name="submit" value="Search" class="btn btn-success"></div>
            </div>
   
            </form>
       
    </div>

    <div class="card-block table-border-style">
        <div class="table-responsive">
            <table class="table table-bordered data-table" style="width:60%" align="center">
                <tbody>    
                    <tr><td colspan="2" class="text-center" style="background:#009E47; color:#FFF">Summary</td></tr>
                    <tr><td>Total treatments performed</td><td>{{ $report_data['total_treatments'] }}</td></tr>
                    <tr><td>Total cancelled treatments</td><td>{{ $report_data['cancelled'] }}</td></tr>
                    <tr><td>Hemodialysis</td><td>{{ $report_data['hemo_modality'] }}</td></tr>
                    <tr><td>Peritoneal Dialysis</td><td>{{ $report_data['cardiac_modality'] }}</td></tr>
                    <tr><td>Treatments performed in the DAY</td><td>{{ $report_data['day_treatments'] }}</td></tr>
                    <tr><td>Treatments performed in the NIGHT</td><td>{{ $report_data['night_treatments'] }}</td></tr>
                    <tr><td>Treatments performed in the WEEKEND</td><td>{{ $report_data['weekend_treatments'] }}</td></tr>
                    <tr><td>Holiday</td><td>{{ $report_data['holiday_treatments'] }}</td></tr>

                    <tr><td colspan="2" class="text-center" style="background:#009E47; color:#FFF">Treatment Goals</td></tr>

                    <tr><td>Achieved Prescribed Time Goal</td><td>{{ ($report_data['goal_meet_time']>0)?number_format($report_data['goal_meet_time']/$report_data['total_treatments']*100,0):0 }}%</td></tr>
                    <tr><td>Achieved Prescribed Ultra Filtration Goal</td><td>{{ ($report_data['goal_meet_uf'] > 0)?number_format($report_data['goal_meet_uf']/$report_data['total_treatments']*100,0):0 }}%</td></tr>

                    <tr><td colspan="2" class="text-center" style="background:#009E47; color:#FFF">Admission Diagnosis Break Down</td></tr>

                    <tr><td>Cardiac Related</td><td>{{ $report_data['cardiac_related'] }}</td></tr>
                    <tr><td>Fever/Sepsis/Infection Related</td><td>{{ $report_data['infection_related'] }}</td></tr>
                    <tr><td>Surgery/Other Scheduled Procedure Related</td><td>{{ $report_data['surgery_related'] }}</td></tr>
                    <tr><td>GI Related</td><td>{{ $report_data['gi_related'] }}</td></tr>
                    <tr><td>Electrolyte Imbalance Related</td><td>{{ $report_data['electrolyte_related'] }}</td></tr>
                    <tr><td>SOB/Fluid Overload Related</td><td>{{ $report_data['sob_related'] }}</td></tr>
                    <tr><td>Physical Injury Related</td><td>{{ $report_data['physical_injury_related'] }}</td></tr>
                    <tr><td>Neural Related</td><td>{{ $report_data['neural_related'] }}</td></tr>
                    <tr><td>Blood Transfusion Related</td><td>{{ $report_data['blood_transfusion_related'] }}</td></tr>
                    <tr><td>Respiratory Related</td><td>{{ $report_data['respiratory_related'] }}</td></tr>
                    <tr><td>Other</td><td>{{ $report_data['other'] }}</td></tr>
                    
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection