@extends("layouts.app")
@section("content")
<div class="card">
    <div class="card-header">
        <h2 class="text-center">Hospital Acute Dialysis</h2>
        <h4 class="text-center">Quarterly Quality Reports</h4>
       
    </div>

    <div class="card-block table-border-style">
        <div class="table-responsive">
            <table class="table table-bordered data-table" style="width:50%" align="center">
                <thead>
                    <tr><th>Date Range</th></tr>
                </thead>
                <tbody> 
                @foreach($data as $each)   
                    <tr><td><a href="{{url("quaterly_each/$each->id")}}">{{ $each->date_range; }}</a></td></tr>
                @endforeach
                    
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection