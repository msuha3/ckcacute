@extends('layouts.app')
@section('content')
    @if ($errors->any())
        {!! implode('', $errors->all('<div class="text-danger">:message</div>')) !!}
    @endif
    <form class="form-material" method="post" action="{{ url('patients') }}">
        @csrf
        @method("PUT")
        <div class="row">
            <div class="col-md-10">
                <div class="card rounded-18 shadow-lg">
                    <div class="card-header">
                        <h5>Patient Update form</h5>

                    </div>
                    <div class="card-block">
                        <div class="row w-100">
                            <div class="col-lg-4">
                                <div class="form-group form-default">
                                    <input type="text" name="account_no" class="form-control" required
                                        value="{{ $patients->account_no }}">
                                    @error('account_no')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="float-label">Account #</label>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="form-group form-default">
                                    <input type="text" name="first_name" class="form-control" required
                                        value="{{ $patients->first_name }}">
                                    @error('first_name')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="float-label">First Name</label>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="form-group form-default">
                                    <input type="text" name="last_name" class="form-control" required
                                        value="{{ $patients->last_name }}">
                                    @error('last_name')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="float-label">Last Name</label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group form-default">
                                    <input type="text" name="contact" class="form-control"
                                        value="{{ $patients->contact }}">
                                    @error('contact')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="float-label">Contact</label>
                                </div>
                            </div>
                        
                            <div class="col-lg-12">
                                <div class="form-group form-default">
                                    <input type="text" name="address" class="form-control"
                                        value="{{ $patients->address }}">
                                    @error('address')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="float-label">Address</label>
                                </div>
                            </div>
                            
                        </div>

                       


                    </div>
                </div>
            </div>
           
        </div>


    </form>
@endsection
