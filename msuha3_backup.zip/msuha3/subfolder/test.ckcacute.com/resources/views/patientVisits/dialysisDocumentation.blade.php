@extends("layouts.app")
@section("content")

<form class="form-material" method="post" action="{{ url('patients/DialysisDocumentation/'.($patient_id ?? '')) }}">
    @csrf
    
    <div class="row">
        <div class="col-md-6">
            <div class="card rounded-18 shadow-lg">
                <div class="card-header">
                    <h5>Dialysis PCT Documentation</h5>
                </div>
                <div class="card-block">
                    <div class="row w-100">
                        <div class="col-lg-6">
                            <label for="">CPR Expiration</label>
                            <div class="form-group form-default">
                                <input class="form-control" type="date" name="cpr_expiration" id="cpr_expiration"
                                value="{{$dialysisDocumentation->cpr_expiration ?? ''}}"
                                >
                                @error('patient_id')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <label for="">Dialysis Certification</label>
                            <div class="form-group form-default">
                                <input class="form-control" type="date" name="dc" id="dc"
                                value="{{$dialysisDocumentation->dc ??''}}"
                                >
                                @error('patient_id')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <label for="">OPH Orientation	</label>
                            <div class="form-group form-default">
                                <input class="form-control" type="date" name="oph" id="oph"
                                value="{{$dialysisDocumentation->oph ?? ''}}"
                                >
                                @error('patient_id')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <label for="">Annual Competence	</label>
                            <div class="form-group form-default">
                                <input class="form-control" type="date" name="ac" id="ac"
                                value="{{$dialysisDocumentation->ac ?? ''}}"
                                >
                                @error('patient_id')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <label for="">Annual Specific Competence	</label>
                            <div class="form-group form-default">
                                <input class="form-control" type="date" name="asc" id="asc"
                                value="{{$dialysisDocumentation->asc ?? ''}}"
                                >
                                @error('patient_id')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div> 

                        <div class="col-lg-6">
                            <label for="">Performance Evaluations	</label>
                            <div class="form-group form-default">
                                <input class="form-control" type="date" name="pe" id="pe"
                                value="{{$dialysisDocumentation->pe ?? ''}}"
                                >
                                @error('patient_id')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div> 
                        <div class="col-lg-6">
                            <label for="">COVID Vaccination 1st Dose	</label>
                            <div class="form-group form-default">
                                <input class="form-control" type="date" name="cv1" id="cv1"
                                value="{{$dialysisDocumentation->cv1 ?? ''}}"
                                >
                                @error('patient_id')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div> 

                        <div class="col-lg-6">
                            <label for="">COVID Vaccination 2nd Dose	</label>
                            <div class="form-group form-default">
                                <input class="form-control" type="date" name="cv2" id="cv2"
                                value="{{$dialysisDocumentation->cv2 ?? ''}}"
                                >
                                @error('patient_id')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div> 
                        <div class="col-lg-6">
                            <label for="">COVID Vaccination Booster	</label>
                            <div class="form-group form-default">
                                <input class="form-control" type="date" name="cvb" id="cvb"
                                value="{{$dialysisDocumentation->cvb ?? ''}}"
                                >
                                @error('patient_id')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div> 
                        <div class="p-4 w-100">
                            <button class="btn btn-primary ">Save</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
@endsection