@extends('layouts.app')
@section('content')
<style>
    .inner-block{
        width: 50px;
        height: 50px;
    }
    .inner-block-selected{
        border: 2px solid black
    }
    table.table-bordered > thead > tr > th{
  border:1px solid black;
}
table.table-bordered > tbody > tr > td{
  border:1px solid black;
}

</style>
    <div class="card">
        <div class="card-header">
            <h5>Patient Record Table</h5>
            <span>use class <code>table</code> inside table element</span>
            <div class="card-header-right">
                <ul class="list-unstyled card-option">
                    <li>
                        <a class="btn btn-primary" href="{{ url('patientVisits/create') }}">Add visit</a>
                    </li>

                </ul>
            </div>
        </div>
        <div class="card-block table-border-style">
            <form action="" method="get">
                <table class="table table-borderless">
                    <tr>
                        
                        <td>
                            Select Hospital: <div>
                                <select name="hospital_id" id="hospital_id">
                                    <option value=""></option>
                                    @foreach(\App\Models\Hospitals::get() as $itemH)
                                    <option 
                                    @if(isset($_GET['hospital_id']) && $_GET['hospital_id'] == $itemH->id) selected @endif
                                    value="{{$itemH->id}}">{{$itemH->name}}</option>
                                    @endforeach
                                </select>
                            </div>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            Tech Name : <div>

                                <select name="user_id" id="user_id">
                                    <option value=""></option>
                                    @foreach (\App\Models\Employee::where('role', 'tech')->get() as $itemTech)
                                        <option @if (isset($_GET['user_id']) && $_GET['user_id'] == $itemTech->id) selected @endif
                                            value="{{ $itemTech->id }}">
                                            {{ $itemTech->first_name . ' ' . $itemTech->last_name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </td>
                        <td>

                            Month Year :
                            <br>

                            {{-- <select name="" id="">
                        <option value="">Jan</option>
                    </select> --}}
                            <input type="month" name="month" id="month" value="{{$_GET['month'] ?? ''}}">
                            {{-- Year :

                            <select name="year" id="month">
                                @for ($i = (int) date('Y'); $i >= 2018; $i--)
                                    <option @if (isset($_GET['year']) && $_GET['yeasr'] == $i) selected @endif value="{{ $i }}">
                                        {{ $i }}</option>
                                @endfor
                            </select> --}}

                            <button class="btn btn-primary btn-sm">
                                apply filter
                            </button>
                        </td>
                    </tr>
                </table>
               
            </form>
            <div class="table-responsive">
                <table class="table table-bordered border-dark table-hover data-table">
                    <thead>
                        <tr>
                            <th></th>
                            <th>#</th>
                            <th>Patient Name
                                
                                <div class="w-100 d-flex">
                                    <div  class="border border-dark px-1"  style="width:50%">
                                        Last name
                                    </div>
                                    <div class="border border-dark px-1" style="width:50%">
                                        First name
                                    </div>
                                    
                                </div>

                            </th>
                            <th>Date</th>
                            <th>Room</th>
                            <th>Account #</th>
                            <th>Dx Code (1-13)</th>
                            <th>
                                Goal Meet
                                <div class="w-100 d-flex">
                                    <div class="border border-dark px-1" style="width:50%">
                                        time<br>
                                        Y/N
                                    </div>
                                    <div  class="border border-dark px-1"  style="width:50%">
                                        uf<br>
                                        Y/N
                                    </div>
                                </div>
                            </th>
                            <th>Modality</th>
                            <th>Time Tx Start</th>
                            <th>Total Tx End</th>
                            <th>Comment/Signature</th>
                            <th>Night Rate?</th>
                            <th>Holiday Rate?</th>
                            <th>Weekend Rate?</th>
                            <th>Status</th>
                            

                            
                            
                            
                            

                            

                            <th>Type</th>
                            
                            
                            <th>Attended By</th>
                            <th>Hospital</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($patientVisits as $key => $item)
                            <?php
                            $patientDetails = \App\Models\Patients::find($item->patient_id);
                            ?>
                            <tr>
                                <td>
                                    <div class="d-inline-flex">
                                        <a href="{{ url('patientVisits/' . $item->id . '/edit') }}"
                                            class="text-success flex  mr-3">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                        <form id="delete-form{{ $item->id }}"
                                            action="{{ url('patientVisits/' . $item->id) }}" method="post"
                                            class="d-none delete-form">
                                            @csrf
                                            @method('DELETE')
                                        </form>
                                        <a href="javascript:confirmDeleteForm('{{ $item->id }}')" {{-- href="javascript:document.getElementById('delete-form{{$item->id}}').submit()" --}}
                                            class="text-danger flex">
                                            <i class="fa fa-trash"></i>
                                        </a>
                                    </div>

                                </td>
                                <td>{{ ++$key }}</td>
                                <td>
                                    <div class="w-100 d-flex">
                                        <div class="border border-dark px-1" style="width:50%">
                                            {{$patientDetails->last_name}}
                                        </div>
                                        <div  class="border border-dark px-1"  style="width:50%">
                                            {{$patientDetails->first_name}}
                                        </div>
                                    </div> </td>
                                <td>{{ $item->date }}</td>
                                <td>{{ $item->room }}</td>
                                <td>{{ $item->patient->account_no }}</td>
                                <td>{{ $item->dx_code }}</td>

                                <td>
                                    <div class="w-100 d-flex">
                                        <div class="border border-dark px-1" style="width:50%">
                                            {{$item->gmt}}
                                        </div>
                                        <div  class="border border-dark px-1"  style="width:50%">
                                            {{$item->gmu}}
                                        </div>
                                    </div> 
                                </td>
                                <td><span class="text-primary">{{ $item->modality }}</span></td>
                                <td>{{ $item->time_start }}</td>
                                <td>{{ $item->time_end }}</td>
                                <td>{{ $item->signature }}</td>
                                <td>{{ $item->night_rate }}</td>
                                <td>{{ $item->holiday_rate }}</td>
                                <td>{{ $item->weekend_rate }}</td>
                                <td>
                                {!!$item->status == "completed" 
                                          ? "<label class='label label-success'>".$item->status."</label>" : ""!!}
                                           {!!$item->status == "pending" 
                                           ? "<label class='label label-danger'>".$item->status."</label>": ""!!}
                                            {!!$item->status == "in progress" 
                                            ? "<label class='label label-primary'>".$item->status."</label>" : ""!!}
                                            {!!$item->status == "cancelled" 
                                            ? "<label class='label' style='background:black;'>".$item->status."</label>" : ""!!}
                                </td>
                                
                                
                                
                                
                                
                                


                                
                                <td>
                                    <div class="d-inline">
                                        <span class="inner-block 
                                        
                                        @if($item->amount !=0)
                                        inner-block-selected
                                        @endif
                                        ">S</span>
                                        <span class="inner-block
                                        @if($item->night_rate !=0)
                                        inner-block-selected
                                        @endif
                                        ">N</span>
                                        <span class="inner-block
                                        @if($item->weekend_rate !=0)
                                        inner-block-selected
                                        @endif
                                        ">W</span>
                                        <span class="inner-block
                                        @if($item->holiday_rate !=0)
                                        inner-block-selected
                                        @endif">H</span>
                                    </div>

                                </td>
                                
                                <td>
                                    @php
                                       $tech =  \App\Models\Employee::where('user_id',$item->user_id)->first();
                                        @endphp
                                    @if($tech)
                                    {{$tech->first_name}}
                                    {{$tech->last_name}}
                                    @endif
                                </td>
                                <td>
                                    {{\App\Models\Hospitals::find($item->hospital_id)->name ?? ''}}

                                </td>



                                
                            </tr>
                        @endforeach


                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
