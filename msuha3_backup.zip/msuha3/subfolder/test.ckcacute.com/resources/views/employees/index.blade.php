@extends("layouts.app")
@section("content")
<div class="card">
    <div class="card-header">
        <h5>Employee Record Table</h5>
        <span>use class <code>table</code> inside table element</span>
        <div class="card-header-right">
            <ul class="list-unstyled card-option">
                <li>
                    <a class="btn btn-primary" href="{{url("employees/create")}}">Add employee</a>
                </li>
                
            </ul>
        </div>
    </div>
    <div class="card-block table-border-style">
        <div class="table-responsive">
            <table class="table table-hover data-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Last Name</th>
                        <th>First Name</th>
                        <th>DOJ</th>
                        <th>DOB</th>
                        <th>Salary</th>
                        <th>Role</th>
                        <th>Account Status</th>
                        <th>Actions</th>
                        </tr>
                </thead>
                <tbody>
                    @foreach ($employees as $key=>$item)
                        
                    
                    <tr>
                        <td>{{++$key}}</td>
                        <td>{{$item->first_name}}</td>
                        <td>{{$item->last_name}}</td>
                        <td>{{$item->doj}}</td>
                        <td>{{$item->dob}}</td>
                        <td>{{$item->salary}}</td>
                        <td>{{$item->role}}</td>
                        <td>
                         {!! ($item->status == "1")
                         ? "<span class='text-success'>Active</span>" 
                         : "<span class='text-danger'>Inactive</span>"  !!}   
                        </td>
                       
                        
                        <td>
                            <div class="d-inline-flex">
                                <a 
                                href="{{url("employees/".$item->id."/edit")}}"
                                class="text-success flex  mr-3">
                                    <i class="fa fa-edit"></i>
                                </a>
                                <form
                                id="delete-form{{$item->id}}" 
                                action="{{url("employees/".$item->id)}}" method="post" class="d-none delete-form">
                                @csrf
                                @method("DELETE")
                                </form>
                                <a
                                href="javascript:confirmDeleteForm('{{$item->id}}')"
                                {{-- href="javascript:document.getElementById('delete-form{{$item->id}}').submit()"  --}}
                                    
                                    class="text-danger flex">
                                    <i class="fa fa-trash"></i>
                                </a>
                            </div>
                            
                        </td>
                    </tr>
                    @endforeach
                   
                   
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection