@extends('layouts.app')
@section('content')
    @if ($errors->any())
        {!! implode('', $errors->all('<div class="text-danger">:message</div>')) !!}
    @endif
    <form class="form-material" method="post" action="{{ url('employees/'.$employee->id) }}">
        @csrf
        @method('PUT')
        <div class="row">
            <div class="col-md-12">
                <div class="card rounded-18 shadow-lg">
                    <div class="card-header">
                        <h5>Patient Update] form</h5>

                    </div>
                    <div class="card-block">
                        <div class="row w-100">
                            <div class="col-lg-6">
                                <div class="form-group form-default">
                                    <input type="text" name="first_name" class="form-control" required
                                        value="{{ $employee->first_name }}">
                                    @error('first_name')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="float-label">First Name</label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group form-default">
                                    <input type="text" name="last_name" class="form-control" required
                                        value="{{ $employee->last_name }}">
                                    @error('last_name')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="float-label">Last Name</label>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group form-default">
                                    <input type="date" name="doj" class="form-control" required
                                        value="{{ $employee->doj }}">
                                    @error('doj')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="">Date of Joining</label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group form-default">
                                    <input type="date" name="dob" class="form-control" required
                                        value="{{ $employee->dob }}">
                                    @error('dob')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="">Date of Birth</label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group form-default">
                                    <input type="number" name="salary" id="salary" class="form-control" required
                                        value="{{ $employee->salary }}">
                                    @error('salary')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="">Salary</label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group form-default">
                                    <select  name="role" id="role" class="form-control" required
                                        
                                    >
                                    <option value="tech" {{ ($employee->role=="tech")?"selected":"" }}>Tech</option>
                                    <option value="lab attendant" {{ ($employee->role=="lab attendant")?"selected":"" }}>lab attendant</option>
                                    <option value="etc" {{ ($employee->role=="etc")?"selected":"" }}>etc</option>
                                    </select>
                                    <!-- <script>
                                         $("#role").val("{{$employee->role}}").attr("selected","selected");
                                    </script> -->
                                    @error('role')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="">Role</label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group form-default">
                                    <select  name="status"
                                    id="status" class="form-control" required
                                        >
                                        <option value="1">Active</option>
                                        <option value="0">Inactive</option>
                                    </select>
                                    <script>
                                        $("#status").val("{{$employee->status}}").attr("selected","selected");
                                   </script>
                                    @error('role')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="">Status</label>
                                </div>
                            </div>
                            <div class="col-lg-6" id="login-detail" style="display:{{ ($employee->role == 'tech') ? 'block' : 'none' }}">

                                <input type="hidden" name="user_id" value="{{ $employee->user->id }}">

                                <div class="form-group form-default">
                                    <input type="email" name="email" class="form-control"
                                        value="{{ $employee->user->email }}">
                                    @error('email')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="float-label">Email</label>
                                </div>

                                <div class="form-group form-default">
                                    <input type="password" name="password" class="form-control"
                                        value="{{ old('password') }}">
                                    @error('password')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="float-label">Password</label>
                                </div>
                            </div>
                            <div class="p-4 w-100">
                                <button class="btn btn-primary ">Save</button>
                            </div>

                        </div>

                     
                    </div>
                </div>
            </div>
        
        </div>


    </form>
@endsection
