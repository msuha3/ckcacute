@extends('layouts.app')
@section('content')
    @if ($errors->any())
        {!! implode('', $errors->all('<div class="text-danger">:message</div>')) !!}
    @endif
    <form class="form-material" method="post" action="{{ url('employees') }}" enctype="multipart/form-data">
        @csrf
        <div class="row">
            <div class="col-md-12">
                <div class="card rounded-18 shadow-lg">
                    <div class="card-header">
                        <h5>Employee Add Form</h5>

                    </div>
                    <div class="card-block">
                        <div class="row w-100">
                            <div class="col-lg-6">
                                <div class="form-group form-default">
                                    <input type="text" name="first_name" class="form-control" required
                                        value="{{ old('first_name') }}">
                                    @error('first_name')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="float-label">First Name</label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group form-default">
                                    <input type="text" name="last_name" class="form-control" required
                                        value="{{ old('first_name') }}">
                                    @error('last_name')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="float-label">Last Name</label>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group form-default">
                                    <input type="date" name="doj" class="form-control" required
                                        value="{{ old('doj') }}">
                                    @error('doj')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="">Date of Joining</label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group form-default">
                                    <input type="date" name="dob" class="form-control" required
                                        value="{{ old('dob') }}">
                                    @error('dob')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="">Date of Birth</label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group form-default">
                                    <input type="number" name="salary" class="form-control" required
                                        value="{{ old('salary') }}">
                                    @error('salary')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="">Salary</label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group form-default">
                                    <select  name="role" id="role" class="form-control" required
                                        >
                                        <option value="">Please Select</option>
                                        <option value="tech">Tech</option>
                                        <option value="lab attendant">lab attendant</option>
                                        <option value="etc">etc</option>
                                    </select>
                                    @error('role')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="">Role</label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group form-default">
                                    <select  name="status" class="form-control" required
                                        >
                                        <option value="1">Active</option>
                                        <option value="0">Inactive</option>
                                    </select>
                                    @error('role')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="">Status</label>
                                </div>
                            </div>
                            <div class="col-lg-6" id="login-detail" style="display: none;">
                                <div class="form-group form-default">
                                    <input type="email" name="email" class="form-control"
                                        value="{{ old('email') }}">
                                    @error('email')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="float-label">Email</label>
                                </div>

                                <div class="form-group form-default">
                                    <input type="password" name="password" class="form-control"
                                        value="{{ old('password') }}">
                                    @error('password')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="float-label">Password</label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group form-default">
                                     <input type="file" name="document" class="form-control"
                                        value="{{ old('document') }}">
                                    @error('document')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <label class="">Document</label>
                                </div>
                            </div>
                            <div class="p-4 w-100">
                                <button class="btn btn-primary ">Save</button>
                            </div>

                        </div>

                     
                    </div>
                </div>
            </div>
        
        </div>


    </form>

@endsection
